#include <Arduino.h>
#include <SoftwareSerial.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <AltSoftSerial.h>

int ledPin = 13;
unsigned long timing = 0;

LiquidCrystal_I2C lcd(PCF8574_ADDR_A21_A11_A01);

AltSoftSerial BTserial;
char c = ' ';

bool connected = false;

void initLCD()
{
  lcd.begin(16, 2);    // Инициализация дисплея
  lcd.backlight();     // Подключение подсветки
  lcd.setCursor(0, 0); // Установка курсора в начало первой строки
}

void setup()
{
  Serial.begin(9600);
  pinMode(ledPin, OUTPUT);
  initLCD();
  BTserial.begin(9600);
}

void printMessageOnLed(String s)
{
  lcd.setCursor(0, 1);
  lcd.print("                ");
  lcd.setCursor(0, 1);
  lcd.print(s);
}

void loop()
{
  if(!connected) {
  if (millis() - timing > 200)
  {
    digitalWrite(ledPin, !digitalRead(ledPin));
    timing = millis();
  }
  }

  if (BTserial.available())
  {
    String s = BTserial.readString();
  if(s.equals("Connected")) {
    connected = true;
  }

    Serial.print(s);
    printMessageOnLed(s);
  }

  if (Serial.available())
   {
      c = Serial.read();
      // Символы CR и LF (/r и /n) не отправляются к HM-10 в качестве
      // окончания строки:
      if (c!=10 & c!=13 ) 
      {
         BTserial.write(c);
      }
      // Эхо пользовательского ввода в главное окно.
      // Если новая строка, то печатается символ ">".
      //if (NL) { Serial.print("\r\n>");  NL = false; }
      Serial.write(c);
      //if (c == 10) { NL = true; }
   }
}